rm(list = ls())
library(data.table)
library(lubridate)

options(digits=15)

#setwd('C:\\Users\\ptlad\\OneDrive\\Desktop\\Study\\MasterThesis\\TimeStamp Bug Files')
setwd('~/Dropbox/Academics/Research/UCSC/NasdaqParsing/TimeStampDiffs/')

# Compute time differences for date/msg type ------------------------------
dateStr = '051118'
msgType = 'E'
shawTimes = fread(paste0('S',dateStr,'-',msgType,'-Shaw-time.csv'),col.names = 'ShawTime')
uiucTimes = fread(paste0('S',dateStr,'-',msgType,'-UIUC-time.csv'),col.names = 'UiucTime')
allTimes = data.table(shawTimes,uiucTimes)
allTimes$TimeDiff = allTimes$ShawTime - allTimes$UiucTime
summary(allTimes$TimeDiff)

# Summary ####

# summary #1: 05/10/18 | Message E | Timestamp for ShawParser - Timestamp for UIUCParser
#Min.              1st Qu.           Median          Mean             3rd Qu.           Max. 
#0.000000000000    0.016843008001    4.311810303996  524.682900694656 1099.528470784004 1103.823438080013

# summary #2: 05/11/18 | Message E |  Timestamp for ShawParser - Timestamp for UIUCParser 
#Min.              1st Qu.           Median          Mean             3rd Qu.           Max. 
#0.000000000000    0.016843008001    4.311810303996  525.287866665864 1099.528470784004 1103.823438080013

# summary #3: 05/10/18 | Message P | Timestamp for ShawParser - Timestamp for UIUCParser
#Min.              1st Qu.           Median          Mean             3rd Qu.           Max. 
#0.000000000000    0.016843008001    4.311810047999  507.826069692399 1099.528470783996 1103.823438080006

# summary #4: 05/11/18 | Message P |  Timestamp for ShawParser - Timestamp for UIUCParser 
#Min.              1st Qu.           Median          Mean             3rd Qu.           Max. 
#0.000000000000    0.016843008001    4.311810047999  507.949158770451 1099.528470783996 1103.823438080006
